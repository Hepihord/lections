using System;
using System.Formats.Asn1;

class Program {
  static void Main() {
      Console.WriteLine("Пожалуйста, введите строку");
      string? input = Console.ReadLine();
      Console.WriteLine("Пожалуйста, введите символ, колличество которого мы будем искать в строке");
      char index = Convert.ToChar(Console.ReadLine());
      int same = 0;
      if (input != null){
          foreach (char i in input){
              Console.WriteLine(i);
              if (Convert.ToChar(index) == i){
                  same ++;
              }
          }
      }
      Console.WriteLine($"Колличество схожих символов: {same}");
  }
}