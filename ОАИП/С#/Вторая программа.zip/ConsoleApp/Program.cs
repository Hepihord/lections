using System;
using System.Formats.Asn1;

class Program {
  static void Main() {
    Console.WriteLine("Пожалуйста, верхнюю границу диапазона");
    int num; double sum = 0;
    num = Convert.ToInt32(Console.ReadLine());
    for (double i = 1; i <= num; i++){
        sum += 1/i*(i+1);
    }
    Console.WriteLine($"Результат применения функции: {sum}");
  }
}