using System;
using System.Formats.Asn1;

class Program {
  static void Main() {
    for (int i = 34; i >= -16; i--){
        Console.WriteLine(i);
    }
    int index = 34;
    while (index >= -16){
        Console.WriteLine(index);
        index -= 2;
    }
    index = 34;
    int sum = 0;
    do {
        sum += index;
        index --;
    }while (index >= -16);
    Console.WriteLine(sum);
  }
}